visit IOTSHARING.COM for more

This library is only for MAX7219.

the original version is for esp8266, I modified a little to adapt with esp32.

Just clone the code and copy it Arduino/libraries folder

Demo 5: How to use Arduino ESP32 to display information on SPI LED matrix
http://www.iotsharing.com/2017/05/how-to-use-arduino-esp32-to-display-spi-led-matrix.html
